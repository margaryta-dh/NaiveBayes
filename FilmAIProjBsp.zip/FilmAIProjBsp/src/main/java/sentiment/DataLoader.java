package sentiment;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class DataLoader {
    public static List<String> readLinesFromClasspath(String resourcePath) throws IOException {
        InputStream in = DataLoader.class.getResourceAsStream(resourcePath);
        if (in == null) return Collections.emptyList();
        List<String> lines = new ArrayList<String>();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) {
                String t = line.trim();
                if (!t.isEmpty()) lines.add(t);
            }
        } finally {
            if (br != null) try { br.close(); } catch (IOException ignore) {}
            try { in.close(); } catch (IOException ignore) {}
        }
        return lines;
    }

    public static Map<String, List<String>> loadLabeledFromClasspath(String posRes, String negRes) throws IOException {
        Map<String, List<String>> data = new HashMap<String, List<String>>();
        data.put("pos", readLinesFromClasspath(posRes));
        data.put("neg", readLinesFromClasspath(negRes));
        return data;
    }
}
