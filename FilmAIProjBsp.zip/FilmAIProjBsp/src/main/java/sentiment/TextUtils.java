package sentiment;
import java.text.Normalizer;
import java.util.*;

public class TextUtils {
    private static final Set <String> STOPWORDS = new HashSet<>(Arrays.asList(
            "der","die","das","und","oder","ein","eine","einer","einem","einen","den",
            "ist","sind","war","waren","sein","mit","auf","zu","von","für","an",
            "im","in","am","ich","du","er","sie","es","wir","ihr","man","auch","nicht",
            "sehr","viel","mehr","wenig","aber","nur","so","noch","wie","als"
    ));
    public static List<String> tokensize(String text){
        if (text==null) {
            return Collections.emptyList();
        }
            String norm = Normalizer.normalize(text.toLowerCase(Locale.ROOT),Normalizer.Form.NFKC);
            norm = norm.replaceAll("[^\\p{L}\\p{Nd}]+", " ").trim();
            if (norm.isEmpty()) {
                return Collections.emptyList();
            }
                String[] raw = norm.split("\\s+");
                List<String>tokens = new ArrayList<>(raw.length);
                for (String w:raw){
                    if (w.length()<=1)continue;
                    if (STOPWORDS.contains(w))continue;
                    tokens.add(w);
                }
                return tokens;

    }
}
